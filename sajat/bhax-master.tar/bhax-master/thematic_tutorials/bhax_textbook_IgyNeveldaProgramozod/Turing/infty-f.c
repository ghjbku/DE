#include <unistd.h>
int
main ()
{
  for (;;)
    sleep(1);
    
  return 0;
}
